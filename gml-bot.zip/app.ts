require('dotenv').config();
import * as express from 'express';
import * as body_parser from 'body-parser';
import * as uuidv1 from 'uuid/v1';
import * as discord from 'discord.js';

const messages = {};
let message_queue = [];
let error_queue: Error[] = [];
const app = express();
app.use(body_parser.json());
app.use(body_parser.urlencoded({extended:false}));
const client = new discord.Client();

client.on('error',(e)=>{
    console.error(e);
    error_queue.push(e);
});

client.on('message',(msg)=>{
    if (msg.author.bot) {
        return;
    }
    message_queue.push({
        id:msg.id,
        content:msg.content
    });
    messages[msg.id] = msg;

});

app.post('/login',(req,res)=>{
    const uuid = uuidv1();
    console.log(req.body);
    client.on('login',()=>{
        console.log(`Bot ${uuid} logged in`);
    });
    client.login(req.body.token);
    res.json({status:'ready', uuid: uuid});

})

app.get('/app/ping',(req,res)=> {
    // basic ping
    res.send({status:'success'});
}); 

app.get('/msg/get',(req,res)=>{
    res.json({
        num:message_queue.length,
        messages:message_queue
    });
    message_queue = [];
});


app.post('/msg/respond',async (req,res)=>{
    console.log(req.body);
    const msg: discord.Message | undefined = messages[req.body.id];
    if (msg == undefined) {
        return res.json({
            status:'failure',
            reason:`Message id ${req.body.id} is not accessible`
        });
    }
    
    if (req.body.delete == true || req.body.delete == 1) {
        if (msg.deletable) {
            msg.delete();
        }
    }
    
    if (req.body.reply != undefined && req.body.reply.trim() != "") {
        msg.channel.send(req.body.reply);
    }

    res.json({
        status: 'success'
    })
});

app.listen(process.env.PORT);